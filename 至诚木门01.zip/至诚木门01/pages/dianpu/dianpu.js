
Page({

  /**
   * 页面的初始数据
   */
  data: {
    classfiySelect: "",
    leftText: [{
      id: "01",
      text1: "德式浮雕",
    },
    {
      id: "02",
      text1: "轻奢干漆",
    },
    {
      id: "03",
      text1: "零度浮雕",
    },
    {
      id: "04",
      text1: "肤感系列",
    },
    {
      id: "05",
      text1: "简约系列",
    },
   {
     id:"06",
      text1: "零度韩式",
    },
    {
      id:"07",
      text1:"韩式拼接",
    },
    {
      id:"08",
      text1:"内凸欧式"
    },

    ],
    rightData: [{
      id: "01",
      title: "德式浮雕",
      frist: [{
        url: "/image/DS-039xyb+lkx.jpg",
        text: "DS-039象牙白+浅蓝扣线",
        money: 888,
        sum: 694,
        id: 1,
      },
      {
        url: "/image/602xyb+hkt.jpg",
        text: "602象牙白+黑卡条",
        money: 888,
        sum: 364,
        id: 2,
      },
      {
        url: "/image/601tyh+bkx.jpg",
        text: "601钛银灰+白扣线",
        money: 888,
        sum: 208,
      },
      ],
    },
    {
      id: "02",
      title: "轻奢干漆",
      frist: [{
        url: "/image/A-02ql.jpg",
        text: "A-02浅兰",
        money: 888,
        sum: 206,
      },
      {
        url: "/image/A-05gjh.jpg",
        text: "A-05 高级灰",
        money: 888,
        sum: 461,
      },
      {
        url: "/images/DS-030szm1.jpg",
        text: "卡姿兰补水套装",
        money: 888,
        sum: 594,
      },
      ],
    },
    {
      id: "03",
      title: "零度浮雕",
      frist: [{
        url: "/image/ld8801fdb.jpg",
        text: "零度-8801 浮雕白",
        money: 888,
        sum: 671,
      },
      {
        url: "/image/ld8803fdb.jpg",
        text: "零度-8803 浮雕白",
        money: 888,
        sum: 121,
      },
      {
        url: "/image/L-302hs.jpg",
        text: "L-302 灰色",
        money: 999,
        sum: 312,
      },
      {
        url:"/image/L-305sxt+h.jpg",
        text:"L-305 苏香桐+黑",
        money:888,
        sum:199,
      }
      ],
    },
    {
      id: "04",
      title: "肤感系列",
      frist: [{
        url: "/image/F-01fgh.jpg",
        text: "F-01 肤感红",
        money: 888,
        sum: 641,
      },
      {
        url: "/image/F-03fgh.jpg",
        text: "F-03 肤感黄",
        money: 888,
        sum: 351,
      },
      {
        url: "/image/F-06fgh3h.jpg",
        text: "F-06 肤感黄3号",
        money: 888,
        sum: 417,
      },
      ],
    },
    {
      id: "05",
      title: "简约系列",
      frist: [{
        url: "/image/J-009hhtm.jpg",
        text: "J-009 红胡桃木",
        money: 888,
        sum: 718,
      },
      {
        url: "/image/J-011swkjm2hh.jpg",
        text: "J-011 竖纹科技木2号黄",
        money: 888,
        sum: 818,
      },
      {
        url:"/image/J-013xwkjm1hh.jpg",
        text:"J-013斜纹科技木1号灰",
        money:888,
        sum:612,
      },
      {
        url:"/image/J-019xyb.jpg",
        text:"J-019 象牙白",
        money:888,
        sum:999,
      },
    ],
  },
    {
      id: "06",
      title: "零度系列",
      frist: [{
        url: "/image/ld009yjlps.jpg",
        text: "零度-009 尤加利拼色",
        money: 888,
        sum: 260,
      },
      {
        url: "/image/ld013yjlps.jpg",
        text: "零度-013 尤加利拼色",
        money: 888,
        sum: 209,
      },
      {
        url: "/image/ld010xkm.jpg",
        text: "零度-010 香框木",
        money: 888,
        sum: 820,
      },
      {
        url:"/image/ld003yjlps.jpg",
        text:"零度-003 尤加利拼色",
        money:888,
        sum:699,
      },
      {
        url:"/image/ld010hyt.jpg",
        text:"零度-010 红樱桃",
        money:888,
        sum:616,
      },
    ],
  },
    {
      id:"07",
      title: "韩式拼接",
      frist: [{
        url: "/image/P-033tgym1h.jpg",
        text: "P-033 泰国柚木1号",
        money: 888,
        sum: 342,
      },
      {
        url:"/image/P016jy.jpg",
        text:"P-016 金柚",
        money:888,
        sum:204,
      },
      {
        url:"/image/P-018xyb.jpg",
        text:"P-018 象牙白",
        money:888,
        sum:152,
      }
      ],
    },
    {
      id:"08",
      title:"内凸欧式",
      frist:[{
        url:"/image/S-835xyb.jpg",
        text:"S-835 象牙白",
        money:888,
        sum:342,
      },
      {
        url:"/image/S-891tyhtb.jpg",
        text:"S-891 钛银灰套白",
        money:888,
        sum:416,
      },
      {
        url:"/image/S-855ynxm.jpg",
        text:"S-855 亚尼橡木",
        money:888,
        sum:339,
      }, 
      ]
    }

    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      classfiySelect: this.data.leftText[0].id
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //滚动触发
  scroll: function (e) {
    var scrollTop = e.detail.scrollTop,
      h = 0,
      classfiySelect;
    var that = this;
    that.data.leftText.forEach(function (clssfiy, i) {
      var _h = 26 + that.length(clssfiy['id']) * 102;
      if (scrollTop >= h) {
        classfiySelect = clssfiy['id'];
      }
      h += _h;
      console.log(h);
    })
    that.setData({
      classfiySelect: classfiySelect,
    })
  },
  //求每一栏高度
  length: function (e) {
    var that = this;
    var rightData = that.data.rightData;
    for (var i = 0; i < rightData.length; i++) {
      if (rightData[i]['id'] == e) {
        return rightData[i]['frist'].length;

      }
    }
  },
  //点击左边事件
  left_list: function (e) {
    var that = this;
    var l_id = e.currentTarget.dataset.id;
    that.setData({
      rigId: l_id,
    })
  },
  //跳转详情界面
  particulars: function (e) {

  },
  handleContact(e) {
    console.log(e.path)
    console.log(e.query)
  },
})

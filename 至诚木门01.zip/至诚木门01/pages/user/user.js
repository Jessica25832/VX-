//获取应用实例
const app = getApp()
Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    // 标注的数组, 这个markers最终会在 .wxml中直接被使用, 初始为空, 后面会通过setData方法对他进行赋值.
    markers: [],

  },
  
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },


  // 点击拨打电话

  btn_iphone: function (e) {

    wx.makePhoneCall({

      phoneNumber: '15307259737', //这里是要调取的客服电话

      success: function () {

        console.log("拨打电话成功！")

      },

      fail: function () {

        console.log("拨打电话失败！")

      }

    })

  },

  //地图

  btn_map: function (e) {



    wx.openLocation({

      latitude: 30.237020,
      longitude: 115.350498,

      scale: 18,

      title: "简介",

      name: '至诚木门厂',

      address: '湖北省蕲春县管窑镇三合铺村县道233'
    })
  },
  click: function (e) {
    wx.openLocation({
      latitude: 30.237020,
      longitude: 115.350498,
      scale: 18,
      name: '至诚木门厂',
      address: '湖北省蕲春县管窑镇三合铺村县道233'
    })
  },


  regionchange(e) {
    console.log(e.type)
  },
  // markers的点击事件
  markertap(e) {
    // 点击相应的坐标点取出相应的信息
    console.log(dataArray[e.markerId])
    console.log(e.markerId)
  },
  // control的点击事件
  controltap(e) {
    console.log(e.controlId)
  },
  click: function (e) {
    wx.openLocation({
      latitude: 30.237020,
      longitude: 115.350498,
      scale: 18,
      name: '至诚木门', //自定义
      address: '蕲春县道223' //自定义
    })
  },
  onShareAppMessage: function () {

  },
  touser: function () {
    wx.navigateTo({
      url: '/pages/util/util',
    })
  },
  tozcmm: function () {
    wx.navigateTo({
      url: '/pages/zcmm/zcmm',
    })
  },
  handleContact(e) {
    console.log(e.path)
    console.log(e.query)
  },
})
